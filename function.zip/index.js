"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const logger_1 = __importDefault(require("@byu-oit/logger"));
const node_fetch_1 = __importStar(require("node-fetch"));
const notify_1 = require("./notify");
const env_1 = require("./env");
const logger = (0, logger_1.default)({
    mixin() {
        return { app: env_1.appName };
    }
});
const handler = async function handler(event) {
    if (event.Records.length > 1) {
        const msg = `Too many records found in the sns event. Right now we only support sending one event at a time`;
        logger.error({ event }, msg);
        throw new LambdaFail(msg);
    }
    const result = await (0, node_fetch_1.default)(`${env_1.host}${env_1.path}`, {
        method: 'POST',
        headers: new node_fetch_1.Headers({
            'Content-Type': 'application/json'
        }),
        body: new notify_1.Notify(event.Records[0].Sns).toString()
    });
    const body = await result.json();
    const response = { json: body, status: result.status, statusText: result.statusText };
    if (!result.ok) {
        const msg = `Failed to send alert to ${env_1.host}.`;
        logger.error({ response }, msg);
        throw new LambdaFail(msg, response);
    }
    const msg = `Sent alert to ${env_1.host}.`;
    logger.info({ response }, msg);
    return new LambdaSucceed(msg, body);
};
exports.handler = handler;
class LambdaFail extends Error {
    constructor(msg, data) {
        super(msg);
        this.data = data;
    }
}
class LambdaSucceed {
    constructor(msg, data) {
        this.message = msg;
        this.data = data;
    }
}
