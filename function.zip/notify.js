"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Notify = void 0;
const env_1 = require("./env");
class Notify {
    constructor(sns) {
        this.service = 'Tyk\'s TIM service';
        this.host = env_1.appName;
        this.kb = env_1.kb;
        this.alert_output = sns.Subject;
        this.severity = this.alert_output.toUpperCase().startsWith('ALARM') ? 'CRITICAL' : 'OK';
        const message = JSON.parse(sns.Message);
        this.element = message.AlarmName;
        this.element_monitor = 'AWS Alarm Trigger: ' + JSON.stringify(message.Trigger);
        this.alert_time = sns.Timestamp;
        this.address = '';
        this.ticket = '';
        this.service = '';
    }
    toString() {
        return JSON.stringify({
            host: this.host,
            element: this.element,
            severity: this.severity,
            alert_output: this.alert_output,
            element_monitor: this.element_monitor,
            alert_time: this.alert_time,
            address: this.address,
            ticket: this.ticket,
            kb: this.kb,
            service: this.service
        });
    }
}
exports.Notify = Notify;
